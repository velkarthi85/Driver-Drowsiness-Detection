clc
clear all
close all
warning off
my_folder ="F:\NTHU\filtered\Not_drowsy"; %Folder path where images are present
Filenames=dir(fullfile(my_folder,'*.jpg'))
total_images=numel(Filenames);

for n=1:total_images
    f=fullfile(my_folder,Filenames(n).name);
    our_images=imread(f);
    our_images=imresize(our_images,[227 227]);
    filename1=strcat('frame',num2str(n),'.jpg');
    ImageFolder1="F:\NTHU\Resized\ND";
    FullFileName = fullfile(ImageFolder1, filename1)
    imwrite(our_images, FullFileName);
end


    