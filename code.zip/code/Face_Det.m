net = yolov3('coco');
%net = importDarknetNetwork("F:\github_repo\cfg", "F:\github_repo\weights");
my_folder ="F:\NTHU\Resized\DROWSY"; %Folder path where images are present
Filenames=dir(fullfile(my_folder,'*.jpg'))
total_images=numel(Filenames);

for n=1:total_images
    f=fullfile(my_folder,Filenames(n).name);
    image=imread(f)
% Step 3: Load and preprocess the input image
    image = imresize(image, net.InputSize(1:2));
    image = im2single(image);

% Step 4: Perform face detection using YOLO
    [bboxes, scores, labels] = detect(net, image);

% Step 5: Filter the detections to only keep the faces
    faceIndices = find(contains(labels, 'face'));
    faceBboxes = bboxes(faceIndices, :);
    faceScores = scores(faceIndices);

% Step 6: Display the detected faces on the image
    detectedImage = insertObjectAnnotation(image, 'rectangle', faceBboxes, faceScores);
    filename=strcat('frame',num2str(n),'.jpg');
    ImageFolder="F:\NTHU\face_detection\Drowsy";
    fullFileName = fullfile(ImageFolder, filename)
    imwrite(detectedImage, fullFileName);
end
% imshow(detectedImage);