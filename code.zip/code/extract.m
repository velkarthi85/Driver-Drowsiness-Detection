video = VideoReader("F:\NTHU\YAW\13-MaleGlasses-Yawning.avi");
for img = 1:video.NumberOfFrames;
    filename=strcat('frame',num2str(img),'.jpg');
    b = read(video, img);
    %imwrite(b,filename);
    ImageFolder="F:\NTHU\Dataset\NOT_DROWSY_N1";
    fullFileName = fullfile(ImageFolder, filename)
    imwrite(b, fullFileName);
end
